import objets

pendbl = objets.PenDbl()
pendbl.anim()
