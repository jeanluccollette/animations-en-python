import objets

pencha = objets.PenCha()
pencha.anim()
