import numpy as np
import matplotlib.pyplot as plt
import time
from matplotlib.animation import FuncAnimation


class MethNumInt:
    def rk2(self, f, t, y0):
        y = np.zeros((len(t), len(y0)))
        k1 = np.zeros(len(y0))
        k2 = np.copy(k1)
        y[0, :] = y0[:]
        for n in range(1, len(t)):
            yprec = y[n-1]
            tprec = t[n-1]
            h = t[n]-tprec
            k1[:] = f(tprec, yprec)
            k2[:] = f(tprec+h, yprec+h*k1)
            y[n, :] = yprec+(h/2)*(k1+k2)
        return t, y

    def rk4(self, f, t, y0):
        y = np.zeros((len(t), len(y0)))
        k1 = np.zeros(len(y0))
        k2 = np.copy(k1)
        k3 = np.copy(k1)
        k4 = np.copy(k1)
        y[0, :] = y0[:]
        for n in range(1, len(t)):
            yprec = y[n-1]
            tprec = t[n-1]
            h = t[n]-tprec
            k1[:] = f(tprec, yprec)
            k2[:] = f(tprec+h/2, yprec+(h/2)*k1)
            k3[:] = f(tprec+h/2, yprec+(h/2)*k2)
            k4[:] = f(tprec+h, yprec+h*k3)
            y[n, :] = yprec+(h/6)*(k1+2*k2+2*k3+k4)
        return t, y


class AnimObj():
    def animate(self, n):
        if n == self._Ndeb:
            self._t0 = time.time()
        if n >= self._Ndeb:
            t = time.time()
            if (t-self._t0) <= self.T:
                self._nt = np.floor((t-self._t0)/self.dt)
            else:
                self._nt = np.floor(self.T/self.dt)
            if self._nt > self._nt_prec:
                _, y = self.methode_int(self.F, np.arange(
                    self._nt_prec, self._nt+1)*self.dt, self._yt)
                self._yt = y[-1]
                self._nt_prec = self._nt
        return self.graph(self._yt, self._nt*self.dt)

    def anim(self):
        self._N = int(np.fix(1000*(self.T+self.Tdeb)/self.interval))
        self._Ndeb = int(np.fix(1000*self.Tdeb/self.interval))
        self._nt = 0
        self._nt_prec = 0
        self._t0 = 0
        self._yt = self.y0
        fig = self.init_graph()

        animobj = FuncAnimation(fig, self.animate, frames=self._N,
                                interval=self.interval, blit=True, repeat=False)

        plt.show()


class PenSim(MethNumInt, AnimObj):
    def __init__(self,
                 l=9.81/(4*np.pi**2), g=9.81,
                 T=20, Tdeb=1, interval=10, dt=0.001, y0=[np.pi/20, 0],
                 meth="rk4"
                 ):
        self.l, self.g = l, g
        self.T, self.Tdeb, self.interval, self.dt, self.y0 =\
            T, Tdeb, interval, dt, y0
        self.methode_int = getattr(self, meth)

    def F(self, t, Y):
        l, g = self.l, self.g
        theta = Y[0]
        thetap = Y[1]
        Yp = np.zeros(len(Y))
        Yp[0] = thetap
        Yp[1] = -(g/l)*np.sin(theta)
        return Yp

    def init_graph(self):
        l, g = self.l, self.g
        fig = plt.figure()
        ax = fig.add_subplot(111, aspect='equal', autoscale_on=False,
                             xlim=(-1.2*l, 1.2*l), ylim=(-1.2*l, 1.2*l))
        ax.grid()
        ax.set_title(
            f'l={l:.2f} m, g={g:.2f} m/s^2, période={2*np.pi*np.sqrt(l/g):.2f} s')
        self.listegraph = []
        h, = ax.plot([], [], 'ob-', lw=2)
        self.listegraph.append(h)
        h = ax.text(-l, l, [], backgroundcolor='y', fontweight='bold')
        self.listegraph.append(h)
        return fig

    def graph(self, yt, t):
        X = [0, self.l*np.sin(yt[0])]
        Y = [0, -self.l*np.cos(yt[0])]
        self.listegraph[0].set_data(X, Y)
        self.listegraph[1].set_text(f't={t:.2f}')
        return self.listegraph


class PenDbl(MethNumInt, AnimObj):
    def __init__(self,
                 m1=1, m2=1, l1=1, l2=1, g=9.81,
                 T=20, Tdeb=1, interval=10, dt=0.001, y0=[0.75*np.pi, 0.75*np.pi, 0, 0],
                 meth="rk4"
                 ):
        self.m1, self.m2, self.l1, self.l2, self.g = m1, m2, l1, l2, g
        self.T, self.Tdeb, self.interval, self.dt, self.y0 =\
            T, Tdeb, interval, dt, y0
        self.methode_int = getattr(self, meth)

    def F(self, t, Y):
        m1, m2, l1, l2, g = self.m1, self.m2, self.l1, self.l2, self.g
        theta1, theta2, theta1p, theta2p = Y[0], Y[1], Y[2], Y[3]
        Yp = np.zeros(len(Y))
        A = np.array([[l1*np.cos(theta1-theta2), l2],
                     [(m1+m2)*l1, m2*l2*np.cos(theta1-theta2)]])
        B = np.array([[l1*theta1p**2*np.sin(theta1-theta2)-g*np.sin(theta2)],
                      [-l2*m2*theta2p**2*np.sin(theta1-theta2)-(m1+m2)*g*np.sin(theta1)]])
        sol = np.linalg.solve(A, B)
        Yp[0] = theta1p
        Yp[1] = theta2p
        Yp[2] = sol[0, 0]
        Yp[3] = sol[1, 0]
        return Yp

    def init_graph(self):
        m1, m2, l1, l2 = self.m1, self.m2, self.l1, self.l2
        D = l1 + l2
        fig = plt.figure()
        ax = fig.add_subplot(111, aspect='equal', autoscale_on=False,
                             xlim=(-1.2*D, 1.2*D), ylim=(-1.2*D, 1.2*D))
        ax.grid()
        ax.set_title(
            f'l1={l1:.2f} m, l2={l2:.2f} m, m1={m1:.2f} kg, m2={m2:.2f} kg')
        self.listegraph = []
        h, = ax.plot([], [], 'bo-', lw=2)
        self.listegraph.append(h)
        h = ax.text(-D, D, [], backgroundcolor='y', fontweight='bold')
        self.listegraph.append(h)
        return fig

    def graph(self, yt, t):
        theta1, theta2 = yt[0], yt[1]
        l1, l2 = self.l1, self.l2
        X = [0, l1*np.sin(theta1), l1*np.sin(theta1)+l2*np.sin(theta2)]
        Y = [0, -l1*np.cos(theta1), -l1*np.cos(theta1)-l2*np.cos(theta2)]
        self.listegraph[0].set_data(X, Y)
        self.listegraph[1].set_text(f't={t:.2f}')
        return self.listegraph


class PenCha(MethNumInt, AnimObj):
    def __init__(self,
                 m=0.1, M=0.2, g=9.81, l=0.5,
                 T=20, Tdeb=1, interval=10, dt=0.001, y0=[0, np.pi/10, 0, 0],
                 meth="rk4",
                 tr=2, tcut=9.2,
                 K=np.array(
                     [[-70.71067812, 117.80656658, -41.30227373,  26.21802518]]),
                 G=np.array([-70.71067812])
                 ):
        self.m, self.M, self.g, self.l = m, M, g, l
        self.T, self.Tdeb, self.interval, self.dt, self.y0 =\
            T, Tdeb, interval, dt, y0
        self.methode_int = getattr(self, meth)
        self.tr, self.tcut, self.K, self.G = tr, tcut, K, G

    def F(self, t, Y):
        m, M, g, l = self.m, self.M, self.g, self.l
        theta = Y[1]
        xp = Y[2]
        thetap = Y[3]
        Yp = np.zeros(len(Y))
        u = self.u(t, Y)
        xpp = (u+m*g*np.sin(theta)*np.cos(theta)-m*l*thetap **
               2*np.sin(theta))/(M+m*np.sin(theta)**2)
        thetapp = (xpp*np.cos(theta)+g*np.sin(theta))/l
        Yp[0] = xp
        Yp[1] = thetap
        Yp[2] = xpp
        Yp[3] = thetapp
        return Yp

    def init_graph(self):
        m, M, l, tcut = self.m, self.M, self.l, self.tcut
        fig = plt.figure()
        ax = fig.add_subplot(111, aspect='equal', autoscale_on=False,
                             xlim=(-2*l, 2*l), ylim=(-1.2*l, 1.2*l))
        ax.grid()
        ax.set_title(
            f'm={m:.2f} kg, M={M:.2f} kg, l={l:.2f} m, tcut={tcut:.2f} s')
        self.listegraph = []
        h, = ax.plot([], [], 'bo-', lw=2)
        self.listegraph.append(h)
        h, = ax.plot([], [], 'ro-', lw=2)
        self.listegraph.append(h)
        h = ax.text(-l, l, [], backgroundcolor='y', fontweight='bold')
        self.listegraph.append(h)
        return fig

    def graph(self, yt, t):
        l = self.l
        x = yt[0]
        theta = yt[1]
        self.listegraph[0].set_data(
            [x, x-l*np.sin(theta)], [0, l*np.cos(theta)])
        self.listegraph[1].set_data([-l/2+x, l/2+x], [0, 0])
        self.listegraph[2].set_text(f't={t:.2f}')
        return self.listegraph

    def e(self, t):
        if t <= self.tr:
            return 0
        else:
            return 0.25+0.25*np.sign(np.sin(0.5*np.pi*(t-self.tr)))

    def u(self, t, Y):
        if t <= self.tcut:
            return -self.K@Y+self.G*self.e(t)
        else:
            return 0
