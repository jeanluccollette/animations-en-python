import objets

pensim = objets.PenSim()
pensim.anim()
