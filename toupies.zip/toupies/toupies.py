import numpy as np
import matplotlib.pyplot as plt
import time
from matplotlib.animation import FuncAnimation


class MethNumInt:
    def rk2(self, f, t, y0):
        y = np.zeros((len(t), len(y0)))
        k1 = np.zeros(len(y0))
        k2 = np.copy(k1)
        y[0, :] = y0[:]
        for n in range(1, len(t)):
            yprec = y[n-1]
            tprec = t[n-1]
            h = t[n]-tprec
            k1[:] = f(tprec, yprec)
            k2[:] = f(tprec+h, yprec+h*k1)
            y[n, :] = yprec+(h/2)*(k1+k2)
        return t, y

    def rk4(self, f, t, y0):
        y = np.zeros((len(t), len(y0)))
        k1 = np.zeros(len(y0))
        k2 = np.copy(k1)
        k3 = np.copy(k1)
        k4 = np.copy(k1)
        y[0, :] = y0[:]
        for n in range(1, len(t)):
            yprec = y[n-1]
            tprec = t[n-1]
            h = t[n]-tprec
            k1[:] = f(tprec, yprec)
            k2[:] = f(tprec+h/2, yprec+(h/2)*k1)
            k3[:] = f(tprec+h/2, yprec+(h/2)*k2)
            k4[:] = f(tprec+h, yprec+h*k3)
            y[n, :] = yprec+(h/6)*(k1+2*k2+2*k3+k4)
        return t, y


class AnimObj:
    def animate(self, n):
        if n == self._Ndeb:
            self._t0 = time.time()
        if n >= self._Ndeb:
            t = time.time()
            if (t-self._t0) <= self.T:
                self._nt = np.floor((t-self._t0)/self.dt)
            else:
                self._nt = np.floor(self.T/self.dt)
            if self._nt > self._nt_prec:
                _, y = self.methode_int(self.F, np.arange(
                    self._nt_prec, self._nt+1)*self.dt, self._yt)
                self._yt = y[-1]
                self._nt_prec = self._nt
        self.graph(self._nt*self.dt, self._yt)
        return self.listegraph

    def anim(self):
        self._N = int(np.fix(1000*(self.T+self.Tdeb)/self.interval))
        self._Ndeb = int(np.fix(1000*self.Tdeb/self.interval))
        self._nt = 0
        self._nt_prec = 0
        self._t0 = 0
        self._yt = self.y0
        self.init_graph()

        animobj = FuncAnimation(self.fig, self.animate, frames=self._N,
                                interval=self.interval, blit=True, repeat=False)

        plt.show()


class Toupie(MethNumInt, AnimObj):
    def __init__(self,
                 Inertie=np.array([1, 2.8, 3]),
                 Omega0=np.array([0, 2*np.pi, 2*np.pi*0.02]),
                 Q=np.eye(3),
                 T=20, Tdeb=1, interval=10, dt=0.001,
                 meth="rk4"
                 ):
        self.Inertie = Inertie
        self.T, self.Tdeb, self.interval, self.dt, self.y0 =\
            T, Tdeb, interval, dt, np.concatenate([Omega0, np.reshape(Q, 9)])
        self.methode_int = getattr(self, meth)

    def F(self, t, Y):
        Yp = np.zeros(12)
        Inertie = self.Inertie
        I1, I2, I3 = Inertie[0], Inertie[1], Inertie[2]
        O1, O2, O3 = Y[0], Y[1], Y[2]
        Yp[0] = O2*O3*(I2-I3)/I1
        Yp[1] = O3*O1*(I3-I1)/I2
        Yp[2] = O1*O2*(I1-I2)/I3
        OmegaS = [[0, -O3, O2], [O3, 0, -O1],
                  [-O2, O1, 0]]
        Q = np.reshape(Y[3:12], (3, 3))
        Qp = Q@OmegaS
        Yp[3:12] = np.reshape(Qp, 9)
        return Yp

    def init_graph(self):
        self.fig = plt.figure()
        self.listegraph = []
        ax = self.fig.add_subplot(projection='3d')
        hx, = ax.plot([], [], [], 'g', linewidth=2, label='X')
        self.listegraph.append(hx)
        hy, = ax.plot([], [], [], 'r', linewidth=4, label='Y')
        self.listegraph.append(hy)
        hz, = ax.plot([], [], [], 'b', linewidth=2, label='Z')
        self.listegraph.append(hz)
        h0, = ax.plot([], [], [], 'k', linewidth=4, label='ombre')
        self.listegraph.append(h0)
        ht = ax.text(-1, -1, 2, [], backgroundcolor='y', fontweight='bold')
        self.listegraph.append(ht)
        ax.axes.set_xlim3d(left=-1.2, right=1.2)
        ax.axes.set_ylim3d(bottom=-1.2, top=1.2)
        ax.axes.set_zlim3d(bottom=-1, top=1)
        ax.set_xlabel('X'), ax.set_ylabel('Y'), ax.set_zlabel('Z')
        ax.legend()

    def graph(self, t, Y):
        Q = np.reshape(Y[3:12], (3, 3))
        hx = self.listegraph[0]
        hx.set_data_3d([-Q[0, 0]/2, Q[0, 0]/2],
                       [-Q[1, 0]/2, Q[1, 0]/2],
                       [-Q[2, 0]/2, Q[2, 0]/2])
        hy = self.listegraph[1]
        hy.set_data_3d([0, Q[0, 1]/2], [0, Q[1, 1]/2], [0, Q[2, 1]/2])
        hz = self.listegraph[2]
        hz.set_data_3d([-Q[0, 2]/4, Q[0, 2]/4],
                       [-Q[1, 2]/4, Q[1, 2]/4],
                       [-Q[2, 2]/4, Q[2, 2]/4])
        h0 = self.listegraph[3]
        h0.set_data_3d([0, Q[0, 1]/2], [0, Q[1, 1]/2], [-1, -1])
        ht = self.listegraph[4]
        ht.set_text(f't={t:.2f}s')

    def var_moment_cine(self):
        t = np.arange(0,  np.floor(self.T/self.dt)+1)*self.dt
        _, y = self.methode_int(self.F, t, self.y0)

        MomentCinetique = np.zeros((len(t), 3))
        for n in range(0, len(t)):
            Q = np.reshape(y[n, 3:12], (3, 3))
            MomentCinetique[n, :] = (Q@(self.Inertie*y[n, 0:3]).T).T

        M0 = MomentCinetique[0, :]
        plt.figure()
        plt.plot(t, (MomentCinetique[:, 0]-M0[0])/np.linalg.norm(M0),
                 'r', label='$\\dfrac{\\Delta\\sigma_X(t)}{\\|\\overrightarrow\\sigma(0)\\|}$')
        plt.plot(t, (MomentCinetique[:, 1]-M0[1])/np.linalg.norm(M0),
                 'g', label='$\\dfrac{\\Delta\\sigma_Y(t)}{\\|\\overrightarrow\\sigma(0)\\|}$')
        plt.plot(t, (MomentCinetique[:, 2]-M0[2])/np.linalg.norm(M0),
                 'b', label='$\\dfrac{\\Delta\\sigma_Z(t)}{\\|\\overrightarrow\\sigma(0)\\|}$')
        plt.title('Variation du moment cinétique dans le repère fixe')
        plt.xlabel('temps (en s)')
        plt.grid('on')
        plt.legend()

        plt.figure()
        plt.plot(t, y[:, 0:3]/(2*np.pi))
        plt.legend(['$\\Omega_1$', '$\\Omega_2$', '$\\Omega_3$'])
        plt.grid('on')
        plt.xlabel('temps (en s)')
        plt.ylabel('vitesse (en tours/seconde)')
        plt.title(
            f'vitesses initiales (tr/s) : $\\Omega_1$={self.y0[0]/(2*np.pi):.2f},$\\Omega_2$={self.y0[1]/(2*np.pi):.2f},$\\Omega_3$={self.y0[2]/(2*np.pi):.2f}')

        plt.show()
