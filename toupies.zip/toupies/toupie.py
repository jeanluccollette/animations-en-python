import toupies

toupie = toupies.Toupie()
toupie.anim()
