import numpy as np
import matplotlib.pyplot as plt
import time
from matplotlib.animation import FuncAnimation


class MethNumInt:
    def rk2(self, f, t, y0):
        y = np.zeros((len(t), len(y0)))
        k1 = np.zeros(len(y0))
        k2 = np.copy(k1)
        y[0, :] = y0[:]
        for n in range(1, len(t)):
            yprec = y[n-1]
            tprec = t[n-1]
            h = t[n]-tprec
            k1[:] = f(tprec, yprec)
            k2[:] = f(tprec+h, yprec+h*k1)
            y[n, :] = yprec+(h/2)*(k1+k2)
        return t, y

    def rk4(self, f, t, y0):
        y = np.zeros((len(t), len(y0)))
        k1 = np.zeros(len(y0))
        k2 = np.copy(k1)
        k3 = np.copy(k1)
        k4 = np.copy(k1)
        y[0, :] = y0[:]
        for n in range(1, len(t)):
            yprec = y[n-1]
            tprec = t[n-1]
            h = t[n]-tprec
            k1[:] = f(tprec, yprec)
            k2[:] = f(tprec+h/2, yprec+(h/2)*k1)
            k3[:] = f(tprec+h/2, yprec+(h/2)*k2)
            k4[:] = f(tprec+h, yprec+h*k3)
            y[n, :] = yprec+(h/6)*(k1+2*k2+2*k3+k4)
        return t, y


class AnimObj():
    def animate(self, n):
        if n == self._Ndeb:
            self._t0 = time.time()
        if n >= self._Ndeb:
            t = time.time()
            if (t-self._t0) <= self.T:
                self._nt = np.floor((t-self._t0)/self.dt)
            else:
                self._nt = np.floor(self.T/self.dt)
            if self._nt > self._nt_prec:
                _, y = self.methode_int(self.F, np.arange(
                    self._nt_prec, self._nt+1)*self.dt, self._yt)
                self._yt = y[-1]
                self._nt_prec = self._nt
        self.graph(self._nt*self.dt, self._yt)
        return self.listegraph

    def anim(self):
        self._N = int(np.fix(1000*(self.T+self.Tdeb)/self.interval))
        self._Ndeb = int(np.fix(1000*self.Tdeb/self.interval))
        self._nt = 0
        self._nt_prec = 0
        self._t0 = 0
        self._yt = self.y0
        self.init_graph()

        animobj = FuncAnimation(self.fig, self.animate, frames=self._N,
                                interval=self.interval, blit=True, repeat=False)

        plt.show()

# Ligne RJ45
# V : vitesse de propagation en m/s
# Zc : impédance caractéristique en Ohm
# Re : impédance en entrée de la ligne en Ohm
# Rs : impédance en sortie de la ligne en Ohm
# N : nombre de segments élémentaires pour modéliser la ligne
# D : longueur de la ligne en m
# musec : unité de temps pour l'affichage en s
#          (1e-6 = 1 microseconde correspond à une seconde d'affichage)
# T : durée de la simulation en s
#          (20 = 20 microseconde correspond à 20 secondes d'affichage)
# Tdeb : démarrage de la simulation en s
# interval : période de rafraichissement en ms
# dt : pas de calcul en unité de temps
# meth : méthode d'intégration numérique


class Ligne(MethNumInt, AnimObj):
    def __init__(self,
                 V=2.3e8, Zc=100, Re=0, Rs=np.inf, N=2000, D=500, musec=1e-6,
                 T=20, Tdeb=1, interval=10, dt=0.001,
                 meth="rk4"
                 ):
        self.V, self.Zc, self.Re, self.Rs, self.N, self.D, self.musec =\
            V, Zc, Re, Rs, N, D, musec
        dx = D/N
        C, L = 1/(V*Zc), Zc/V
        self.dx, self.Cdx, self.Ldx = dx, C*dx, L*dx
        self.T, self.Tdeb, self.interval, self.dt, self.y0 =\
            T, Tdeb, interval, dt, np.zeros(2*N)
        self.methode_int = getattr(self, meth)

    def F(self, t, Y):
        N, Re, Rs, Cdx, Ldx = self.N, self.Re, self.Rs, self.Cdx, self.Ldx
        Yp = np.zeros(2*N)
        U = Y[0:N]
        I = Y[N:2*N]
        Yp[0:N] = self.musec*(1/Cdx)*(I-np.concatenate((I[1:N], [U[N-1]/Rs])))
        Yp[N:2*N] = self.musec*(1/Ldx)*(-U+np.concatenate(([self.e(t)-Re*I[0]],
                                                           U[0:N-1])))
        return Yp

    def init_graph(self):
        self.fig = plt.figure()
        self.listegraph = []
        self.fig.set_size_inches(13, 4)
        ax = self.fig.add_subplot(
            111, autoscale_on=False, xlim=(0, self.D), ylim=(-2, 2))
        ax.set_title(f'$Vdt/dx = {self.V*self.dt*self.musec/self.dx:f}$')
        ax.grid()
        ax.set_xlabel('distance (en $m$)')
        ax.set_ylabel('amplitude (en $V$)')
        h, = ax.plot([], [])
        self.listegraph.append(h)
        h = ax.text(self.D/10, 1.5, [], backgroundcolor='y', fontweight='bold')
        self.listegraph.append(h)

    def graph(self, t, Y):
        N, dx = self.N, self.dx
        self.listegraph[0].set_data(np.arange(N)*dx, Y[0:N])
        self.listegraph[1].set_text(f'$t={t:.2f} \mu s$ ')

    def e(self, t):
        Te = 250e-9/self.musec
        if t < Te:
            src = (1-np.cos(2*np.pi*t/Te))/2
        else:
            src = 0
        return src
