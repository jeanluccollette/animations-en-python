import lignes

ligne = lignes.Ligne()
ligne.anim()
